package com.example.juegoelgatoenandroid

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var finJuego=false
        var arr = arrayOf(charArrayOf(' ', ' ', ' '), charArrayOf(' ', ' ', ' '), charArrayOf(' ', ' ', ' '))
        var turno  ='X'
        val button: Button =findViewById(R.id.button)
        val buttonDos: Button =findViewById(R.id.button2)
        val buttonTres: Button =findViewById(R.id.button3)
        val buttonCuatro: Button =findViewById(R.id.button4)
        val buttonCinco: Button =findViewById(R.id.button5)
        val buttonSeis: Button =findViewById(R.id.button6)
        val buttonSiete: Button =findViewById(R.id.button7)
        val buttonOcho: Button =findViewById(R.id.button8)
        val buttonNueve: Button =findViewById(R.id.button9)
        val reiniciar: Button =findViewById(R.id.button10)
        var textView: TextView =findViewById(R.id.textView)
        fun verificarGanador(){
            //validacion horizontal
            if(arr[0][0]==arr[0][1] && arr[0][1]==arr[0][2] && (arr[0][0]!=' ')){
                button.setBackgroundColor(Color.parseColor("red"))
                buttonDos.setBackgroundColor(Color.parseColor("red"))
                buttonTres.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true
            }
            if(arr[1][0]==arr[1][1] && arr[1][1]==arr[1][2] && (arr[1][0]!=' ')){
                buttonCuatro.setBackgroundColor(Color.parseColor("red"))
                buttonCinco.setBackgroundColor(Color.parseColor("red"))
                buttonSeis.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true
            }
            if(arr[2][0]==arr[2][1] && arr[2][1]==arr[2][2] && (arr[2][0]!=' ')){
                buttonSiete.setBackgroundColor(Color.parseColor("red"))
                buttonOcho.setBackgroundColor(Color.parseColor("red"))
                buttonNueve.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true
            }

            //validacion vertical
            if(arr[0][0]==arr[1][0] && arr[1][0]==arr[2][0] && (arr[0][0]!=' ') ){
                button.setBackgroundColor(Color.parseColor("red"))
                buttonCuatro.setBackgroundColor(Color.parseColor("red"))
                buttonSiete.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true
            }
            if(arr[0][1]==arr[1][1] && arr[1][1]==arr[2][1] && (arr[0][1]!=' ') ){
                buttonDos.setBackgroundColor(Color.parseColor("red"))
                buttonCinco.setBackgroundColor(Color.parseColor("red"))
                buttonOcho.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true
            }
            if(arr[0][2]==arr[1][2] && arr[1][2]==arr[2][2] && (arr[0][2]!=' ')){
                buttonTres.setBackgroundColor(Color.parseColor("red"))
                buttonSeis.setBackgroundColor(Color.parseColor("red"))
                buttonNueve.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true


            }
            //validacion diagonal
            if(arr[0][0]==arr[1][1] && arr[1][1]==arr[2][2] && (arr[0][0]!=' ')){
                button.setBackgroundColor(Color.parseColor("red"))
                buttonCinco.setBackgroundColor(Color.parseColor("red"))
                buttonNueve.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true


            }
            if(arr[0][2]==arr[1][1] && arr[1][1]==arr[2][0] && (arr[0][2]!=' ')){
                buttonCinco.setBackgroundColor(Color.parseColor("red"))
                buttonTres.setBackgroundColor(Color.parseColor("red"))
                buttonSiete.setBackgroundColor(Color.parseColor("red"))
                textView.text="Ganador: "+turno
                finJuego=true


            }
        }
        fun cambiarTurno(){
            if(turno=='X'){
                turno='O'
            }
            else turno='X'

        }

    if(finJuego==false){
        button.setOnClickListener{
            if(arr[0][2]==' '){
                arr[0][0]=turno
                button.text=turno.toString()
                verificarGanador()
                cambiarTurno()
            }
        }
        buttonDos.setOnClickListener{
            if(arr[0][1]==' '){
                arr[0][1]=turno
                buttonDos.text=turno.toString()
                verificarGanador()
                cambiarTurno()
            }

        }
        buttonTres.setOnClickListener{

            if(arr[0][2]==' '){
                arr[0][2]=turno
                buttonTres.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        buttonCuatro.setOnClickListener{
            if(arr[1][0]==' '){
                arr[1][0]=turno
                buttonCuatro.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        buttonCinco.setOnClickListener{
            if(arr[1][1]==' '){
                arr[1][1]=turno
                buttonCinco.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        buttonSeis.setOnClickListener{
            if(arr[1][2]==' '){
                arr[1][2]=turno
                buttonSeis.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        buttonSiete.setOnClickListener{
            if(arr[2][0]==' '){
                arr[2][0]=turno
                buttonSiete.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        buttonOcho.setOnClickListener{
            if(arr[2][1]==' '){
                arr[2][1]=turno
                buttonOcho.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        buttonNueve.setOnClickListener{
            if(arr[2][2]==' '){
                arr[2][2]=turno
                buttonNueve.text=turno.toString()
                verificarGanador()
                cambiarTurno()

            }

        }
        reiniciar.setOnClickListener{
            arr = arrayOf(charArrayOf(' ', ' ', ' '), charArrayOf(' ', ' ', ' '), charArrayOf(' ', ' ', ' '))
            button.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonDos.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonTres.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonCuatro.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonCinco.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonSeis.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonSiete.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonOcho.setBackgroundColor(Color.parseColor("#673AB7"))
            buttonNueve.setBackgroundColor(Color.parseColor("#673AB7"))
             button.text=" "
            buttonDos.text=" "
            buttonTres.text=" "
            buttonCuatro.text=" "
            buttonCinco.text=" "
            buttonSeis.text=" "
            buttonSiete.text=" "
            buttonOcho.text=" "
            buttonNueve.text=" "
            textView.text=" "


        }

    }



    }
}